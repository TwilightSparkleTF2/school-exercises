﻿Console.WriteLine("Input num in mm: ");
int number = int.Parse(Console.ReadLine());
int cm = number / 10;
int mm =  number % 10;
Console.WriteLine(cm + "sm." + " and " +  mm + "mm.");
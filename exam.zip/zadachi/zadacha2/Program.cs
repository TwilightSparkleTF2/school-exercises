﻿Console.WriteLine("Input x:");
double x = double.Parse(Console.ReadLine());
double y;
if (x <= 5)
{
    y = x % 2;
}
else
{
    y = x * x;
}
Console.WriteLine("y=" + y);
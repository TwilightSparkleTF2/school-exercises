﻿int num = int.Parse(Console.ReadLine());
if (num > 0)
    {
        if (num % 2 == 0)
        {
            Console.WriteLine("Positive even");
        }
        else
        {
            Console.WriteLine("Positive odd");
        }
    }
    else
    {
        Console.WriteLine("Not positive");
    }

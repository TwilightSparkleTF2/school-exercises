﻿int a = int.Parse(Console.ReadLine());
int b = int.Parse(Console.ReadLine());
if (a > b)
{
    if ((a - b) > 10)
    {
        Console.WriteLine("Big difference");
    }
    else
    {
        Console.WriteLine("Small difference");
    }
}
else
{
    Console.WriteLine("a is not greater than b");
}
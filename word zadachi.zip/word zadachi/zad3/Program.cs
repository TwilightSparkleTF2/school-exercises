﻿int x = int.Parse(Console.ReadLine());
if (x >= 1 && x <= 100)
{
    if (x % 5 == 0)
    {
        Console.WriteLine("Valid and divisible by 5");
    }
    else
    {
        Console.WriteLine("Valid but not divisible by 5");
    }
}
else
{
    Console.WriteLine("Invalid number");
}
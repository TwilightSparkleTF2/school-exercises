﻿int age = int.Parse(Console.ReadLine());
char hasCard = char.Parse(Console.ReadLine());
if (age >= 18)
{
    if (hasCard == 'y')
    {
        Console.WriteLine("Access granted");
    }
    else
    {
        Console.WriteLine("No access card");
    }
}
else
{
    Console.WriteLine("Underage");
}
﻿double grade = double.Parse(Console.ReadLine());
if (grade >= 2.00 && grade <= 6.00)
{
    if (grade >= 5.50)
    {
        Console.WriteLine("Excellent");
    }
    if (grade >= 4.50 && grade < 5.50)
    {
        Console.WriteLine("Very good");
    }
    if (grade >= 3 && grade < 4.50)
    {
        Console.WriteLine("Passed");
    }
    if (grade < 3 && grade >= 2)
    {
        Console.WriteLine("Failed");
    }
}
else
{
    Console.WriteLine("Invalid grade");
}
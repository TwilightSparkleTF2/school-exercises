﻿int points = int.Parse(Console.ReadLine());
bool hasBonus = bool.Parse(Console.ReadLine());
if (points >= 50)
{
    if (hasBonus == true)
    {
        Console.WriteLine("passed with bonus");
    }
    else
    {
        Console.WriteLine("passed");
    }
}
else
{
    Console.WriteLine("failed");
}
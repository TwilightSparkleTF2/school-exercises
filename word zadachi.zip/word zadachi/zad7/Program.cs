﻿int days = int.Parse(Console.ReadLine());
bool hasAbsences = bool.Parse(Console.ReadLine());
if (days <= 30)
{
    if (hasAbsences == true)
    {
        Console.WriteLine("Invalid due to absences");
    }
    else
    {
        Console.WriteLine("Valid participation");
    }
}
else
{
    Console.WriteLine("Invalid due to too many days");
}
﻿int tasksSolved = int.Parse(Console.ReadLine());
int errors = int.Parse(Console.ReadLine());
if (tasksSolved >= 5)
{
    if (errors == 0)
    {
        Console.WriteLine("Perfect performance");
    }
    else if (errors != 0 && errors <=2)
    {
        Console.WriteLine("Good performance");
    }
    else
    {
        Console.WriteLine("Needs improvement");
    }
}
else
{
    Console.WriteLine("Insufficient tasks");
}
﻿using System;

class Program
{
    static void Main()
    {
        Console.Write("Въведете сума за теглене: $");
        int amount = int.Parse(Console.ReadLine());

        // Banknote denominations
        int twenty = 20;
        int ten = 10;
        int five = 5;
        int one = 1;

        // Calculate number of each banknote
        int count20 = amount / twenty;
        amount %= twenty;

        int count10 = amount / ten;
        amount %= ten;

        int count5 = amount / five;
        amount %= five;

        int count1 = amount / one;

        // Prepare output message
        string result = "";

        if (count20 > 0)
            result += $"{count20} от $20";

        if (count10 > 0)
        {
            if (!string.IsNullOrEmpty(result))
                result += ", ";
            result += $"{count10} от $10";
        }

        if (count5 > 0)
        {
            if (!string.IsNullOrEmpty(result))
                result += ", ";
            result += $"{count5} от $5";
        }

        if (count1 > 0)
        {
            if (!string.IsNullOrEmpty(result))
                result += " и ";
            result += $"{count1} от $1";
        }

        Console.WriteLine(result);
    }
}
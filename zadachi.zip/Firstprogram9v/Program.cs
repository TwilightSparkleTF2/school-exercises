﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Firstprogram9v
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("*");
            Console.WriteLine("**");
            Console.WriteLine("***");
            Console.WriteLine("****");
            Console.WriteLine("*****");
            Console.WriteLine("******");
            Console.WriteLine("*******");
            Console.WriteLine("********");
            Console.WriteLine("*********");
            Console.WriteLine("**********");
            Console.WriteLine("***********");
            Console.WriteLine("    *");
            Console.WriteLine("   ***");
            Console.WriteLine("  *****");
            Console.WriteLine(" *******");
            Console.WriteLine("*********");
            Console.WriteLine("   **    ");
            Console.WriteLine("   **    ");
            Console.WriteLine("    oo     oo");
            Console.WriteLine(" oo    o    oo");
            Console.WriteLine("oo           oo");
            Console.WriteLine(" oo         oo");
            Console.WriteLine("  oo       oo");
            Console.WriteLine("    o     o");
            Console.WriteLine("       o");
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestInt
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Number of bones: ");
            int numBones = int.Parse(Console.ReadLine());
            Console.Write("Number of dogs: ");
            int numDogs = int.Parse(Console.ReadLine());
            if (numDogs == 0)
            {
                Console.WriteLine("Cannot divide by zero dogs");
            }
            Console.WriteLine("each dog will get " + (numBones / numDogs));
        }
    }
}

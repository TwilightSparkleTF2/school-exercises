﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TestWrite
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input your name: ");
            string name = Console.ReadLine();
            Console.Write("Input your last name: ");
            string LastName = Console.ReadLine();
            Console.Write("Your age: ");
            string age = Console.ReadLine();
            Console.Write("Hello, ");
            Console.WriteLine(name + " " + LastName + ", " + "Your age is " + age + "!");
            Console.WriteLine($"Hello, {name} {LastName}, Your age is {age}!");

        }
    }
}

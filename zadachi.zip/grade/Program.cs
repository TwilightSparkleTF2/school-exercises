﻿double points = double.Parse(Console.ReadLine());
double maxPoints = 50;
double sum = 2 + (points / maxPoints) * 4;
double suma = Math.Round(sum, 2);
Console.WriteLine(suma);
double decimalPart = sum - Math.Floor(sum);
//if (decimalPart > 0.50)
//{
//    sum = Math.Truncate(sum);
//}
//else if (decimalPart < 0.50) {
//    sum = Math.Truncate(sum);
//}
Console.WriteLine(Math.Round(sum));
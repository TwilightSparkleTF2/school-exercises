﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hell_but_worse
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input a 3 digit num:");
            int num = int.Parse(Console.ReadLine());
            int ed = num % 10;
            int des = (num /10) % 10;
            int st = (num / 10) / 10;
            // we get each num eg. if number is 123 we get the numbers 1, 2 and 3
            int num1 = st * 100 + ed * 10 + des;
            int num2 = des * 100 + st * 10 + ed;
            int num3 = des * 100 + ed * 10 + st;
            int num4 = ed * 100 + st * 10 + des;
            int num5 = ed * 100 + des *10 + st;
            //there are only 5 possible solutions if the numbers dont repeat themselves AND its a 3 digit number
            Console.WriteLine($"New number1: {num1}");
            Console.WriteLine($"New number2: {num2}");
            Console.WriteLine($"New number3: {num3}");
            Console.WriteLine($"New number4: {num4}");
            Console.WriteLine($"New number5: {num5}");
            int sum = num1 + num2 + num3 + num4 + num5 + num;
            Console.WriteLine($"The sum is: {sum}");
        }
    }
}

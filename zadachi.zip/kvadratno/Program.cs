﻿// ax^2 + bx + c = 0

double a = double.Parse(Console.ReadLine());
double b = double.Parse(Console.ReadLine());
double c = double.Parse(Console.ReadLine());

double D = (b * b) - (4 * a * c);
if (a !=  0)
{
    if (D > 0)
    {
        Console.WriteLine($"x1 = {(-b + Math.Sqrt(D)) / (2 * a)} x2 = {(-b - Math.Sqrt(D)) / (2 * a)}");
    }
    else if (D == 0)
    {
        Console.WriteLine($"x = {-b / (2 * a)}");
    }
    else
    {
        Console.WriteLine("no solution");
    }
}

else
{
    if (b != 0)
    {
        Console.WriteLine($"x = {-c / b}");
    }
    if (b == 0 && c == 0)
    {
        Console.WriteLine("every x is a solution");
    }
    if (b == 0 && c != 0)
    {
        Console.WriteLine("no solution");
    }
}
﻿// ax + b = 0

double a = double.Parse(Console.ReadLine());
double b = double.Parse(Console.ReadLine());
double x;
if  (a == 0)
{
    if (b == 0)
    {
        Console.WriteLine("0");
    }
    else
    {
        Console.WriteLine("no solution");
    }
}
if (a != 0)
{
    x = -b / a;
    Console.WriteLine(x);
}
else
{
    if (b != 0)
    {
        Console.WriteLine("no solution");
    }
    else
    {
        Console.WriteLine("every x is solution");
    }
}
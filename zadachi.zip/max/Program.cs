﻿Console.WriteLine("number 1: ");
int num1 = int.Parse(Console.ReadLine());
Console.WriteLine("number 2: ");
int num2 = int.Parse(Console.ReadLine());
if (num1 > num2)
{
    Console.WriteLine($"{num1} is bigger than {num2}");
}
else if (num1 == num2)
{
    Console.WriteLine($"{num1} is equal to {num2}");
}
else
{
    Console.WriteLine($"{num2} is bigger than {num1}");
}
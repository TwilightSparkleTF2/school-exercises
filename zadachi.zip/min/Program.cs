﻿Console.WriteLine("Input a: ");
int a = int.Parse(Console.ReadLine());
Console.WriteLine("Input b: ");
int b = int.Parse(Console.ReadLine());

if (a < b)
{
    a = a * 2;
}
if (b < a)
{
    b = b * 2;
}
if (a == b)
{
    a = 3 * a;
    b = 3 * b;
}
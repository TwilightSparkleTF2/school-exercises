﻿Console.WriteLine("Input money in lv: ");
int lv = int.Parse(Console.ReadLine());
Console.WriteLine("Input money in st: ");
int st = int.Parse(Console.ReadLine());

int totalSt = lv * 100 + st;
Console.WriteLine("stotinki count: " + totalSt);
﻿int num = int.Parse(Console.ReadLine());
int rev = 0;
int original = num;

rev = rev * 10 + num % 10;
num /= 10;

rev = rev * 10 + num % 10;
num /= 10;

rev = rev * 10 + num % 10;
num /= 10;

rev = rev * 10 + num % 10;

int result = original + rev;

Console.WriteLine(result);

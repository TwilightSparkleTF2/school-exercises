﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace reverseNumber
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int num = 0;
            Console.Write("Input two digit number: ");
            num = int.Parse(Console.ReadLine());
            Console.WriteLine("Your number is " + num);
            int des = num / 10;
            int edi = num % 10;
            int rev = edi * 10 + des;
            Console.WriteLine("Reverse number is " + rev);
            int pro = num * rev;
            Console.Write("Product: " + num + "*" + rev + " " + "=" + " " + pro);
        }
    }
}

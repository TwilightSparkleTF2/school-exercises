﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace swap
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.Write("Input num a: ");
            int a = int.Parse(Console.ReadLine());
            Console.Write("Input num b: ");
            int b = int.Parse(Console.ReadLine());
            int c = a;
            a = b;
            b = c;
            Console.WriteLine("a = " + a);
            Console.WriteLine("b = " + b);
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace taxi
{
    internal class Program
    {
        static void Main(string[] args)
        {
            const float a = 2.50f;
            const float b = 1.20f;
            Console.Write("km = ");
            float h = float.Parse(Console.ReadLine());
            float sum = a + (b * h);
            Console.WriteLine("Sum: " + sum);
        }
    }
}

﻿Console.WriteLine("Input age: ");
int age = int.Parse(Console.ReadLine());
if (age <= 19 && age >= 13)
{
    Console.WriteLine("teen");
}
else
{
    Console.WriteLine("not a teen");
}
﻿Console.Write("st=");
int num = int.Parse(Console.ReadLine());
int lv = num / 100;
int st = num % 100;
Console.WriteLine($"{lv} lv. {st} st.");
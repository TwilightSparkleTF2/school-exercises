﻿Console.Write("a=");
int a = int.Parse(Console.ReadLine());
Console.Write("b=");
int b = int.Parse(Console.ReadLine());

int sum = a * b;

if ((sum % 10) % 2 == 0)
{
    Console.WriteLine($"{sum % 10} - even");
}
else
{
    Console.WriteLine($"{sum % 10} - odd");
}
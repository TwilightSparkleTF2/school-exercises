﻿double a = double.Parse(Console.ReadLine());
double b = double.Parse(Console.ReadLine());
double c = Math.Sqrt((a * a) + (b * b));
Console.WriteLine($"alea a + alea b: {a + b}");
Console.WriteLine($"shortcut: {c:f2}");
Console.WriteLine($"less with: {((a + b) - c):f2}");